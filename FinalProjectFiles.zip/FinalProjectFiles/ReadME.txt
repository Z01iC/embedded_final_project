-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
IHEART-EMBEDDED: HAMILTON LEE AND ZOLTAN CSAKI
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
This zip file contains the entire code-base for
the iHeart-Embedded final project. Code organization
is pretty standard:

TremorDetector.c -> Contains main function and main
			loop for program logic.
TremorDetector.h -> Contains variable definitions used in
			main program display cycles
utils.c & utils.h -> Utility functions for the MK64F (same as
			the functions used in the previous labs)
3140_i2c.c, 3140_i2c.h, 3140_serial.c & 3140_serial.h -> Used for exactly 
			how they are named. Provided by code uploaded 
			by the TAs.
ADC.c & ADC.h -> The C file contains all code necessary fro ADC conversion
			for our accelerometer. The header file contains 
			pin definitions that are used to do the readings
			along with other constants/
LEDMat.c & LEDMat.h -> contains all definitions for pins and constants along
			with functions to interface with the ADAFruit LED
			Matrix.
matrixCol.c & matrixCol.h -> contains all functions relating to columnwise
			animation of the LED Matrix along with functions to
			convert data to a form readible by the LED matrix
			through I2C.
shared_structs.h -> contains struct definitions for accelerometer data and linked
			list for storing column data used for animating the matrix


You should be able to create a new project through the standard procedure on
microVision and import all these files. Note that when setting up the project,
you may have to include i2c, gpio, in the project setup window. After project is
created, you have to change the FCPU definition in the setup window along with
change the heap size to 1000. The assembly file also needs to be changed in order
to run I2C0, but all these steps are covered in the tutorial video on I2C on canvas.

If those steps are followed, all that needs to be done is to import these files and
the program should run.